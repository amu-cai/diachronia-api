from dariah.config import Endpoints


def main():
    print("Hello, Dariah!", Endpoints.dating.value)


if __name__ == "__main__":
    main()
