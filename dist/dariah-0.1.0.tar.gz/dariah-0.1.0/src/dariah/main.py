from dariah.models import dating


def main():
    print(dating("bogurodzica"))
    pass


if __name__ == "__main__":
    main()
